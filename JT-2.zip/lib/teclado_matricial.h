#include "m5272gpio.h"

int get_teclado(void);