
int get_teclado(void);