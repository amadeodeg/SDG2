#include <stdio.h>

int get_teclado(void){
	return getchar();
}