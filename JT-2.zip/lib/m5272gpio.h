#include "m5272.h"
#include "m5272lib.c"

void set16_puertoS (UWORD valor);
UWORD lee16_puertoS (void);
UWORD lee16_puertoE(void);
UBYTE lee_puertoE(void);