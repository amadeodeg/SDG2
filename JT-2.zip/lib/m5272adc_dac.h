
//inicializacion de ADC y DAC
void DAC_ADC_init();

//pasar dato al DAC
void DAC_dato(int dato);

//lee ADC
int ADC_dato();

