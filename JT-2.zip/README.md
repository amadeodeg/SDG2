# SDG2
Visualizador de Señales en dominio de frecuencia
