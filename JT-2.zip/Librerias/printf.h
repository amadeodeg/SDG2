
#ifndef __PRINTF_H
#define __PRINTF_H
void	_printf(char*,...);
#endif